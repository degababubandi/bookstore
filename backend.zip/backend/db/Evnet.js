const mongoose = require("mongoose");

const eventSchema = mongoose.Schema({
    name:String,
    price:String,
    author:String,
    publish:String,
    category:String,
    userId:String
});
module.exports = mongoose.model("events",eventSchema);